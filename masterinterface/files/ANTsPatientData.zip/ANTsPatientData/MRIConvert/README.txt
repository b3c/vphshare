README for MRIConvert
20131202

Installation
------------
First, unzip the distribution file into a convenient location. If you
are reading this file, you have already done so.

MRIConvert and mcverter are immediately available for use at the 
location referenced above.
