Data Publication Suite Test Data
--------------------------------

To use this test dataset you must extract this folder and its contents to c:\temp\PlausibleACSData. Because of the absolute path references in the data and the project file any other locations will cause the publication process to fail.

To load the test project open the Data Publication Suite, goto File -> Open and select sth_acs_dataset.dps. This project contains a source which connects to the test data with renamed fields. To publish the data you must create a destination by right-clicking on the source, selecting "add as destination" and following the instructions.

Please see the manual for instructions on all the other processes you might wish to do with the DPS.

NOTE: The file prpocessing part of the system is still quite untested by anoyone outside the development team and so may behave unexpectidley. If you have any experience with using it we would appreciate your feedback.